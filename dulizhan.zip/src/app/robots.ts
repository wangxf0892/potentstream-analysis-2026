// src/app/robots.ts
import { MetadataRoute } from 'next';

export default function robots(): MetadataRoute.Robots {
  return {
    rules: {
      userAgent: '*',
      disallow: '/', // 禁止爬虫抓取任何页面，因为我们做的是直接截流，不需要搜索收录
    },
  };
}